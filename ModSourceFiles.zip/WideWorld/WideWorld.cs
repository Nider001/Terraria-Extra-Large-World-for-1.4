using Microsoft.Xna.Framework.Graphics;
using System;
using System.Reflection;
using Terraria;
using Terraria.Map;
using Terraria.ModLoader;

namespace WideWorld
{
    public class WideWorld : Mod
    {

        public override void Load()
        {
            base.Load();

            On.Terraria.WorldGen.clearWorld += WorldGen_clearWorld;
        }

        private void WorldGen_clearWorld(On.Terraria.WorldGen.orig_clearWorld orig)
        {
            Main.rightWorld = 268800f;
            Main.maxTilesX = 16800;

            Main.mapTargetX = 20;
            Main.mapTargetY = 2;
            Main.instance.mapTarget = new RenderTarget2D[Main.mapTargetX, Main.mapTargetY];

            int intendedMaxX = 16800;
            int intendedMaxY = 2400;

            // Individual map tiles
            Main.Map = new WorldMap(intendedMaxX, intendedMaxY);

            // Space for more tiles -- Actual tiles
            Main.tile = new Tile[intendedMaxX, intendedMaxY];
            // Color for each tile

            Main.initMap = new bool[Main.mapTargetX, Main.mapTargetY];
            Main.mapWasContentLost = new bool[Main.mapTargetX, Main.mapTargetY];

            orig();
        }
    }
}